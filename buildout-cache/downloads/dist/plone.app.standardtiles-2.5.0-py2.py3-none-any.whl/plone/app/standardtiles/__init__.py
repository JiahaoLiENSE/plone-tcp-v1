# -*- coding: utf-8 -*-
from zope.i18nmessageid import MessageFactory


PloneMessageFactory = MessageFactory("plone")

_PMF = PloneMessageFactory
