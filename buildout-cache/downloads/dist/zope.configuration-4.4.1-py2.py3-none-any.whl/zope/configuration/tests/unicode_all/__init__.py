from __future__ import unicode_literals

__all__ = ['foo']

foo = 'sentinel'
