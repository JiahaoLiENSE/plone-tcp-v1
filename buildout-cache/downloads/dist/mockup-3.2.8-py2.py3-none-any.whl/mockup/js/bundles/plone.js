define([
  'jquery',
  'pat-registry',
  'pat-base',

  'mockup-patterns-select2',
  'mockup-patterns-pickadate',
  'mockup-patterns-relateditems',
  'mockup-patterns-querystring',
  'mockup-patterns-tinymce',

  'mockup-patterns-autotoc',
  'mockup-patterns-datatables',
  'mockup-patterns-formunloadalert',
  'mockup-patterns-preventdoublesubmit',
  'mockup-patterns-formautofocus',
  'mockup-patterns-modal',
  'mockup-patterns-navigationmarker',
  'mockup-patterns-structure',
  'mockup-patterns-textareamimetypeselector',
  'bootstrap-dropdown',
  'bootstrap-collapse'
], function($, registry, Base) {
  'use strict';

  // BBB: we need to hook pattern to classes which plone was using until now
  var Plone = Base.extend({
    name: 'plone',
    init: function() {}
  });

  // initialize only if we are in top frame
  if (window.parent === window) {
    $(document).ready(function() {
      $('body').addClass('pat-plone');
      if (!registry.initialized) {
        registry.init();
      }
    });
  }
  return Plone;
});
