############################################################################
#
# Copyright (c) 2002 Zope Foundation and Contributors.
#
# This software is subject to the provisions of the Zope Public License,
# Version 2.1 (ZPL).  A copy of the ZPL should accompany this distribution.
# THIS SOFTWARE IS PROVIDED "AS IS" AND ANY AND ALL EXPRESS OR IMPLIED
# WARRANTIES ARE DISCLAIMED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF TITLE, MERCHANTABILITY, AGAINST INFRINGEMENT, AND FITNESS
# FOR A PARTICULAR PURPOSE
#
############################################################################

access_session_data = 'Access session data'
access_user_session_data = 'Access arbitrary user session data'
add_browser_id_managers = 'Add Browser Id Manager'
add_session_data_managers = 'Add Session Data Manager'
change_browser_id_managers = 'Change Browser Id Manager'
change_session_data_managers = 'Change Session Data Manager'
