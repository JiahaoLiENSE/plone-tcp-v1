plone.app.customerize Package Readme
====================================

Overview
--------

This package integrates five.customerize into Plone, which enables site
administrators to customize five/zope3-style views TTW via the ZMI in a
way similar to it's possible to customize filesystem-based skin elements
via the portal skin "customize" procedure.

