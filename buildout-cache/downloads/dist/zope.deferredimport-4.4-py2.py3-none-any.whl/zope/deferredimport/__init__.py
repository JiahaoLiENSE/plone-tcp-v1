from zope.deferredimport.deferredmodule import initialize
from zope.deferredimport.deferredmodule import define, defineFrom
from zope.deferredimport.deferredmodule import deprecated, deprecatedFrom


__all__ = (
    'initialize',
    'define',
    'defineFrom',
    'deprecated',
    'deprecatedFrom',
)
