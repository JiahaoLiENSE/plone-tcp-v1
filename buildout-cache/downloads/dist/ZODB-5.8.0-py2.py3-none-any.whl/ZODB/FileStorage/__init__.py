# this is a package

from ZODB.FileStorage.FileStorage import FileIterator
from ZODB.FileStorage.FileStorage import FileStorage
from ZODB.FileStorage.FileStorage import Record
from ZODB.FileStorage.FileStorage import TransactionRecord
from ZODB.FileStorage.FileStorage import packed_version


# BBB Alias for compatibility
RecordIterator = TransactionRecord
