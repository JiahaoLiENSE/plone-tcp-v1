# -*- coding: utf-8 -*-
from zope.deferredimport import deprecated


deprecated(
    "Import from Products.CMFPlone.patterns.view instead",
    PatternSettings="Products.CMFPlone.patterns.view.PatternSettingsView",
)
