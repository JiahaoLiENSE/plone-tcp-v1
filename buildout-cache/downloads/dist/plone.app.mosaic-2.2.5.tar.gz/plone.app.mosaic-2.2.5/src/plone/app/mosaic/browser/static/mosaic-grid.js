// Dummy JS file for mosaic-grid bundle
