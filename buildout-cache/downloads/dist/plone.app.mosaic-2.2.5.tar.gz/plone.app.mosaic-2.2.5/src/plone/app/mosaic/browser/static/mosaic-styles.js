// Dummy JS file for mosaic-styles bundle
