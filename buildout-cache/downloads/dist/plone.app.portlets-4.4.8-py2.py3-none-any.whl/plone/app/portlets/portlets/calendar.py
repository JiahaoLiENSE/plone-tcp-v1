# -*- coding: utf-8 -*-
# avoid broken persistent object
from plone.app.event.portlets.portlet_calendar import Assignment
