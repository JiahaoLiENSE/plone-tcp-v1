
  [ ] Test:

    - placing a value in an annotation (needs to remain persistent)
    - versioning/rollback (CMFEditions may have problems with blobs)
