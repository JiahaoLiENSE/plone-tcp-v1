=================
 ZCML directives
=================

This package registers two new ZCML directives. These are:

    <plone:registerCondition /> -- used to register a new type of condition
    <plone:registerAction /> -- used to register a new type of action

We have created a dummy condition and a dummy action in
plone.contentrules.rule.tests.elements. We haven't bothered to register an
addview or an edit view, but in real life we would need to do so using the
usual <browser:page /> directives or similar.

Here is how we would register these in ZCML:

    >>> zcml = """\
    ... <configure package="plone.contentrules"
    ...            xmlns="http://namespaces.zope.org/zope"
    ...            xmlns:plone="http://namespaces.plone.org/plone">
    ...
    ...     <plone:ruleCondition
    ...         name="test.condition"
    ...         title="Test condition"
    ...         description="A test condition"
    ...         for="*"
    ...         event="zope.interface.interfaces.IObjectEvent"
    ...         addview="test.condition"
    ...         editview="edit"
    ...         schema=".rule.tests.elements.ITestCondition"
    ...         factory=".rule.tests.elements.TestCondition"
    ...         />
    ...
    ...     <plone:ruleAction
    ...         name="test.action"
    ...         title="Test action"
    ...         description="A test action"
    ...         for="*"
    ...         event="zope.interface.interfaces.IObjectEvent"
    ...         addview="test.action"
    ...         editview="edit"
    ...         schema=".rule.tests.elements.ITestAction"
    ...         factory=".rule.tests.elements.TestAction"
    ...         />
    ... </configure>
    ... """

    >>> from zope.configuration.xmlconfig import xmlconfig
    >>> import six
    >>> from six import StringIO

First, we need to make sure the ZCML directives are defined:

    >>> from zope.configuration.xmlconfig import XMLConfig
    >>> import plone.contentrules
    >>> XMLConfig('meta.zcml', plone.contentrules)()

Then we process the ZCML string above:

    >>> xmlconfig(StringIO(zcml))

The end result should be two new utilities. These can be used create and
inspect conditions and actions in rules.

    >>> from plone.contentrules.rule.interfaces import IRuleCondition
    >>> from plone.contentrules.rule.interfaces import IRuleAction

    >>> from zope.component import getUtility
    >>> from zope.interface.interfaces import IObjectEvent
    >>> from plone.contentrules.rule.tests import elements

    >>> condition = getUtility(IRuleCondition, name=u"test.condition")
    >>> condition.title
    'Test condition'
    >>> condition.description
    'A test condition'
    >>> condition.for_ == None
    True
    >>> condition.event == IObjectEvent
    True
    >>> condition.addview
    'test.condition'
    >>> condition.editview
    'edit'
    >>> condition.schema == elements.ITestCondition
    True
    >>> condition.factory == elements.TestCondition
    True

    >>> action = getUtility(IRuleAction, name=u"test.action")
    >>> action.title
    'Test action'
    >>> action.description
    'A test action'
    >>> action.for_ == None
    True
    >>> action.event == IObjectEvent
    True
    >>> action.addview
    'test.action'
    >>> action.editview
    'edit'
    >>> action.schema == elements.ITestAction
    True
    >>> action.factory == elements.TestAction
    True
