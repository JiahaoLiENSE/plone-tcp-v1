Components
==========

.. warning::
   The @components endpoint is deprecated and has been removed in plone.restapi
   1.0b1. :doc:`breadcrumbs` and :doc:`navigation` are now top-level endpoints.

How to get pages components (i.e. everything but the main content), like breadcrumbs, navigations, actions, etc.
