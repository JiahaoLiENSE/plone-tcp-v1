# -*- coding: utf-8 -*-
"""Interfaces."""
from zope.interface import Interface


class IJsonSchemaProvider(Interface):
    pass
