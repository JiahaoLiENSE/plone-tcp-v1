Software translation files
==========================

This directory contains translation files and utilities for
translating the software strings for the Zope application server
software.
