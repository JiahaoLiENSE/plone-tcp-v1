This is a sub directory within a skin.

Please keep this file: if the directory is empty, it will not be kept
in git version control and it will not end up in a released package.
