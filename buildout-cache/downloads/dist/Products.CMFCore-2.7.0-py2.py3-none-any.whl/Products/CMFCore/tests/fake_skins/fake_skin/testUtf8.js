﻿/*
 * This file starts with an UTF-8 BOM: 0xEF 0xBB 0xBF
*/
var drink = "café";
