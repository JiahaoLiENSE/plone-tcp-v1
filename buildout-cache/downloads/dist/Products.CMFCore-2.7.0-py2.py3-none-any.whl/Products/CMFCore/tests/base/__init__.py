"""
Generic stuff for unit testing the CMF.
"""
