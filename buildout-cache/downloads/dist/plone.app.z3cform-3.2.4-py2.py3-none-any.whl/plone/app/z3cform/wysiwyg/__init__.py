# -*- coding: utf-8 -*-
# Convenience import
from plone.app.z3cform.wysiwyg.widget import WysiwygFieldWidget


WysiwygFieldWidget  # flake 8 happiness
