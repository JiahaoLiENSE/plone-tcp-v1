from z3c.objpath import path as _path
from z3c.objpath.path import path
from z3c.objpath.path import resolve
