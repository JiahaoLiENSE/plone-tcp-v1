Overview
========

This package provides a variant of the persistent base class that's an
ExtensionClass_. Unless you need ExtensionClass_ semantics, you probably want to
use ``persistent.Persistent`` from the persistent_ distribution (formerly in ZODB3).

.. _ExtensionClass : https://pypi.org/project/ExtensionClass/
.. _persistent : https://pypi.org/project/persistent/
