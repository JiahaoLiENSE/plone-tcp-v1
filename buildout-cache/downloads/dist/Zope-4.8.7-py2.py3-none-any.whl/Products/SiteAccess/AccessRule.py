# BBB
from ZPublisher.BeforeTraverse import NameCaller as AccessRule


# Use the import, to please both flake8 and isort.  'noqa' did not help.
AccessRule
