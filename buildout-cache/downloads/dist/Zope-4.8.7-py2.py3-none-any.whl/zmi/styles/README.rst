zmi.styles
**********

Introduction
============

This library packages the resources used to style the ZMI with 
Bootstrap.

It uses the `Font Awesome`_ font for the icons.

.. _`Font Awesome`: https://fontawesome.com

Contents
========

* Bootstrap CSS and JS
* FontAwesome
* jQuery
* custom CSS and JS for the ZMI


Usage
=====

See https://zope.readthedocs.io/en/4.x/zope4/migration/code.html#migrating-to-the-new-bootstrap-based-zmi
