This directory typically contains the database files.
