try:
    # PY2
    text_type = unicode
except NameError:
    # PY3
    text_type = str
