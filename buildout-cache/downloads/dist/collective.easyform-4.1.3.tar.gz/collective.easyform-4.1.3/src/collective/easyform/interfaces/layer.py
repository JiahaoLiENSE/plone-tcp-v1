# -*- coding: utf-8 -*-
from plone.app.z3cform.interfaces import IPloneFormLayer


class IEasyFormLayer(IPloneFormLayer):
    """Request layer installed via browserlayer.xml"""
