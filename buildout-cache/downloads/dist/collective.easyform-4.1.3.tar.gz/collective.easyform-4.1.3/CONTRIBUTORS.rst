Contributors
============

EasyForm was originally developed by `QuintaGroup <http://quintagroup.com/>`_.
It was moved over to the Collective repository and developed further for use with Plone 5.
Google Summer of Code student Prakhar Joshi pushed a lot further.

- Roman Kozlovskyi, krzroman@gmail.com
- Johannes Raggam, thetetet@gmail.com
- Giorgio Borelli, hpeter@agitator.com
- Fred van Dijk, fredvd@gmail.com
- Zoriana Zaiats
- Tom Gross
- Prakhar Joshi, prakhar126@gmail.com
- Nathan Van Gheem, vangheem@gmail.com
- Jens W. Klein, jens@bluedynamics.com
- Peter Holzer, peter.holzer@agitator.com
- Thomas Massmann, thomas.massmann@it-spir.it
- T. Kim Nguyen, kim.nguyen@wildcardcorp.com
- Quang Nguyen, quang.nguyen@pretagov.com.au
- Jon Pentland, jon.pentland@pretagov.co.uk
