Adding EasyForm
===============

Adding as Manager
-----------------

.. image:: images/add-new-menu.png

.. image:: images/new-easyform-default.png

.. image:: images/new-easyform-overrides.png

.. image:: images/new-easyform-thankspage.png

.. image:: images/created-easyform.png

Default fields
^^^^^^^^^^^^^^

.. image:: images/created-easyform-fields.png

Default actions
^^^^^^^^^^^^^^^

.. image:: images/created-easyform-actions.png

Adding as Contributor
---------------------

.. image:: images/add-new-menu.png

.. image:: images/new-easyform-default-contributor.png

.. image:: images/new-easyform-thankspage-contributor.png

.. image:: images/created-easyform.png
