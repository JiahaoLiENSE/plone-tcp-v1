Tests
=====

Acceptance tests cases
----------------------

.. robot_tests::
   :source: ../collective/easyform/tests/robot/tests.robot

Acceptance tests keywords
-------------------------

.. robot_keywords::
   :source: ../collective/easyform/tests/robot/keywords.robot

Acceptance tests settings
-------------------------

.. robot_settings::
   :source: ../collective/easyform/tests/robot/tests.robot
