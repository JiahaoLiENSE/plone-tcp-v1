# plone.jsonserializer

JSON Serialization/Deserialization resources for Plone
