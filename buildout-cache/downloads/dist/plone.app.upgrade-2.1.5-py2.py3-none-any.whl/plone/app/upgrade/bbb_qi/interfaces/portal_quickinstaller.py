# -*- coding: utf-8 -*-
from zope.interface import Interface


class IQuickInstallerTool(Interface):
    pass

class IInstalledProduct(Interface):
    pass
