# -*- coding: utf-8 -*-
from OFS.SimpleItem import SimpleItem
# from Products.CMFQuickInstallerTool.interfaces.portal_quickinstaller import IInstalledProduct  # noqa
# from zope.interface import implementer


# @implementer(IInstalledProduct)
class InstalledProduct(SimpleItem):
    pass
