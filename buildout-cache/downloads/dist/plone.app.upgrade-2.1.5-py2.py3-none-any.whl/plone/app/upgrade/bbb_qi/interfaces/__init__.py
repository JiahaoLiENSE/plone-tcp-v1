# -*- coding: utf-8 -*-
from .installable import INonInstallable
from .portal_quickinstaller import IQuickInstallerTool


INonInstallable   # pyflakes
IQuickInstallerTool   # pyflakes
