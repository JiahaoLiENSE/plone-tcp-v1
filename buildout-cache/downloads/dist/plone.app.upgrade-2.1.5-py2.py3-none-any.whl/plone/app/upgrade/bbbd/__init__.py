# -*- coding: utf-8 -*-
from .LanguageTool import LanguageTool  # noqa F401
