from zope.i18nmessageid import MessageFactory
MessageFactory = MessageFactory('z3c.formwidget.query')
