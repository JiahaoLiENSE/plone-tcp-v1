""" nice docstring """


class A:
    pass

# comment


def inc(i):
    return i + 1


def greater(a, b):
    """foo <html />"""
    return a > b
