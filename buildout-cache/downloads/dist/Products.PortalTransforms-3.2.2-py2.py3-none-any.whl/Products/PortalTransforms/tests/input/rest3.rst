=====
Title
=====

--------
Subtitle
--------

This is a test document to make sure subtitle gets the right heading.

Now the real heading
====================

The brown fox jumped over the lazy dog.

With a subheading
------------------

Some text, bla ble bli blo blu. Yes, i know this is Stupid_.

.. _Stupid: http://www.example.com

