# -*- coding: utf-8 -*

import logging


logger = logging.getLogger("plone.gallery")
