Update resources
================

To update resource files after running npm or yarn, you can use the following
command:

npm run update-dist-files

This will copy the needed files into the static/dist folder, but will not
override existing files. So if you want files, which are already there,
delete them.
